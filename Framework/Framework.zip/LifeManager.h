#pragma once
#include "Scene.h"
#include "GameObject.h"
class LifeManager
	:public GameObject
{public:
	LifeManager(int life);
	void static changeLife(int changelife);
	static int life;
	Scene& s;
	static GameObject* remainlife1;
	static GameObject* remainlife2;
};
