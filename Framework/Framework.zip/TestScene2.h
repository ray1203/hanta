#pragma once
#include "Scene.h"
class TestScene2 :
	public Scene
{
public:
	virtual void Initialize();
};

