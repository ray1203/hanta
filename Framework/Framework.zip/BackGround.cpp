#include "stdafx.h"
#include "BackGround.h"

BackGround::BackGround(const wchar_t* path) :GameObject(path)
{
}
