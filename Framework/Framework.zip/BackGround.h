#pragma once
#include "GameObject.h"
class BackGround :
	public GameObject
{
public:
	BackGround(const wchar_t* path);
};

